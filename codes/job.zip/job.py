from selenium import webdriver

driver = webdriver.Chrome('c:\wyy\webdrivers\chromedriver.exe')
driver.implicitly_wait(10)

# 打开网页
driver.get('https://www.51job.com/')
ele = driver.find_element_by_id('kwdselectid')

# 输入python
ele.send_keys('python')

# 在首页点击城市
city = driver.find_element_by_id('work_position_input')
city.click()

# 定位选择城市的页面
cityPage = driver.find_element_by_id('work_position_layer')
hangzhou = cityPage.find_element_by_id('work_position_click_center_right_list_category_000000_080200')
hangzhou.click()

# 已经选择的城市，只保留杭州一个
selectedCities = cityPage.find_elements_by_css_selector('#work_position_click_multiple_selected span.ttag')
if (len(selectedCities)>1):  # 找到不是杭州的已选城市，并逐一移除，确保最后只留下杭州一个
    for one in selectedCities:
        if one.text.strip() == '杭州':
            continue
        one.find_element_by_tag_name('em').click()

# 在选择城市的页面点击确定
cityPage.find_element_by_id('work_position_click_bottom_save').click()

# 点击搜索按钮
driver.find_element_by_css_selector('.content .fltr.radius_5 .ush.top_wrap button').click()

# 获取格式化信息
driver.implicitly_wait(0.5)  # 为防止找不到表头时不断轮询，暂时将隐式等待时间调短
for one in driver.find_elements_by_css_selector('#resultList .el'):
    if one.find_elements_by_css_selector('span.t1'):  # 如果找到的是表头，不打印
        continue
    t1 = one.find_element_by_css_selector('p.t1 span a').text.strip()
    t2 = one.find_element_by_css_selector('span.t2 a').text.strip()
    t3 = one.find_element_by_css_selector('span.t3').text.strip()
    t4 = one.find_element_by_css_selector('span.t4').text.strip()
    t5 = one.find_element_by_css_selector('span.t5').text.strip()
    print('{} | {} | {} | {} | {}'.format(t1, t2, t3, t4, t5))
driver.implicitly_wait(10)
driver.quit()
